SWARM — complete updated artwork set

136 PNG images from IMAGE_PROMPTS.md, organized together under SWARM/art/.
All filenames and specified dimensions are preserved. Transparent assets retain genuine alpha.
All 136 were generated individually with the built-in image generator and visually checked.

HOW TO PUT EVERYTHING IN ONE FOLDER
Download every numbered SWARM_Artwork_Part ZIP to the same location.
Extract the contents of each ZIP into the SAME destination, merging the SWARM folder.
These are ordinary independent ZIP files, not multipart .z01 archives. Do not put each extracted
part in its own separate folder. After merging, SWARM/art/ contains all 136 PNGs.
Part 01 contains this README, the full asset manifest and the supplied prompt list.

The original 75 weapon/evolution/passive/item icons are excluded as requested; they were
identified as already made. Previously delivered Vacuum.png was not regenerated.
These are image files only. They have not been uploaded to Roblox or wired into the game.
Some transparent frame centers retain invisible alpha=1 edge noise; original glow is preserved.
The three new store thumbnails and text-free store icon follow the updated requested scenes.

Folders: portraits, arenas, bosses, icons/ui, icons/meta, icons/curses, icons/rewards,
ui/frames, icons/heroes, icons/arenas, icons/achievements, icons/track, icons/shop,
icons/stats, screens, store.
